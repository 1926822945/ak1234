﻿# -*- coding: utf-8 -*-
import requests
import json


def main():
    url = 'http://api.zoomeye.org/dev/?query=app%3A"ThinkPHP%20V5"%20%2Bcountry:"SG"&t=10'
    header = {"API-KEY": "E00AA112-292A-6ACAE-a4f2-8c667bfefd7"}
    r = requests.get(url=url, headers=header)
    data = json.loads(r.text)['matches']
    for data in data:
        print(data['ip'] + ':' + str(data['port']))


if __name__ == '__main__':
    main()
